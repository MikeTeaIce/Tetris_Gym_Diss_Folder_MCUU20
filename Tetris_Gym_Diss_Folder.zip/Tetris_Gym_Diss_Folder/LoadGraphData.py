
import sys
from matplotlib import lines
import matplotlib.pyplot as plt


f = open("SavedTrainingData/4x6rowQ/4x6rowQRowsDeleted1000Episodes_STEPSIZE_0.002.txt", "r")
lines_cleared = f.read().split("\n")
lines_cleared_1  = []
for n in lines_cleared:
    if n != '':
        lines_cleared_1.append(int(n))
print(lines_cleared_1)

f = open("SavedTrainingData/4x6rowQ/4x6rowQRowsDeleted1000Episodes_STEPSIZE_0.02.txt", "r")
lines_cleared = f.read().split("\n")
lines_cleared_2  = []
for n in lines_cleared:
    if n != '':
        lines_cleared_2.append(int(n))
print(lines_cleared_2)

f = open("SavedTrainingData/4x6rowQ/4x6rowQRowsDeleted1000Episodes_STEPSIZE_0.2.txt", "r")
lines_cleared = f.read().split("\n")
lines_cleared_3  = []
for n in lines_cleared:
    if n != '':
        lines_cleared_3.append(int(n))
print(lines_cleared_3)

f = open("SavedTrainingData/4x6rowQ/4x6rowQRowsDeleted1000Episodes_STEPSIZE_0.01.txt", "r")
lines_cleared = f.read().split("\n")
lines_cleared_4  = []
for n in lines_cleared:
    if n != '':
        lines_cleared_4.append(int(n))
print(lines_cleared_4)

average = [7390.7]*1000

plt.title("4x6 Tabular Q-Learning Rows Deleted")
plt.plot(lines_cleared_1, label="LR = 0.002 ")
plt.plot(lines_cleared_2, label="LR = 0.02 ")
plt.plot(lines_cleared_3, label="LR = 0.2 ")
plt.plot(lines_cleared_4, label="LR = 0.01 ")
plt.plot(average, label = "ARA = %g"% (average[0]))
plt.legend()
plt.ylabel("Rows Deleted After 5000 Tetrominos")
plt.xlabel("Episodes")
plt.savefig("SavedTrainingData/4x6rowQ/plottedLearningRateRowsDeleted.png")
plt.show()

