from os import linesep
import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T  
from torch._C import dtype
from DQN.DQN import ReplayMemory, DQN, Experience

def save_data_to_file(data, name):
    f = open(name, 'w')

    #based on the data I choose to save, it will be either a single int or a list of ints 
    #check if data is a single int
    if isinstance(data, int):
        #if yes then save the int itself
        f.write(str(data))
    else: 
        #if not int then it will be a list of ints so iterate through list and save to file
        for val in data:
            f.write(str(val) + '\n')
    f.close()
    return

env = gym.make("StandardTetris-v0")
run_on_device = 'cpu' #Device to run the neural network and tensors on. 'cpu' is CPU, 'cuda' is GPU
#if torch.cuda.is_available():
#    run_on_device = 'cuda'
dqn_input_size = 5
neural_network = DQN(dqn_input_size).to(run_on_device)

#Load Desired Model

    #Uncomment if you want to load the model trained in main4RowHeuristics.py
neural_network.load_state_dict(torch.load("SavedTrainingData/4x10rowHeuristics/saved_neural_network_state_dict.pth")) 

    #Uncomment if you want to load the trandsfer learning model trained in mainRegTetrisTransferLearningHeuristics.py
#neural_network.load_state_dict(torch.load("SavedTrainingData/Reg_Tetris_Transfer_Learning_Heuristics/saved_transfer_learning_neural_network_state_dict.pth"))

    #Uncomment if you want to load the model trained from scratch from mainRegTetrisHeuristicsLearnFromScratch.py
#neural_network.load_state_dict(torch.load("SavedTrainingData/Reg_Tetris_Heuristics_Learn_From_Scratch/saved_learn_from_scratch_neural_network_state_dict.pth"))

neural_network.eval()

results_from_1000_episodes = []
number_episodes = 1000
for episode_number in range(number_episodes):
    terminated = False
    state = env.reset()
    while terminated == False:#
        env.render() #uncomment to render environment
       

        with torch.no_grad():
            #this will capture all possible next state heuristics after taking each possible action
            
          

            #get possible next states, will be given as dictionary {action: state, action2, state2, ...}
            possible_next_states = env.retrieve_poss_next_states_heuristics()
            #print(list(possible_next_states.values()))
            inp_for_neural_network = torch.tensor(list(possible_next_states.values()), dtype=torch.float32)
            taken_actions = list(possible_next_states.keys())
   
            
            max_state_heuristic_value_indice =  torch.argmax(neural_network(inp_for_neural_network))
            
            best_action = taken_actions[max_state_heuristic_value_indice]

            best_next_state = list(possible_next_states.values())[max_state_heuristic_value_indice]
            

            #perform action in Tetris environment
            next_state, reward, terminal = env.step(best_action)
           
            terminated = terminal
            

    print("Episode %d, Lines Cleared: %d, Score: %d" % (episode_number+1, env.get_lines_cleared(), env.get_score()))
    results_from_1000_episodes.append(env.get_lines_cleared())
    #print(terminated)
    #save_data_to_file(results_from_1000_episodes, "SavedTrainingData/Reg_Tetris_playing_with_trained_models/Reg_Tetris_Loaded_model_Lines_Cleared_%d_Episodes.txt" %(number_episodes)) #uncomment to save
    
total = 0
for i in results_from_1000_episodes:
    total += i

average = total // len(results_from_1000_episodes)
print("average")
print(average)
#save_data_to_file(average, "SavedTrainingData/Reg_Tetris_playing_with_trained_models/Reg_Tetris_Loaded_model_Lines_Cleared_average.txt")




