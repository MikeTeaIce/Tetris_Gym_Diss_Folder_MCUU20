import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt


def save_data_to_file(data, name):
    f = open(name, 'w')

    #based on the data I choose to save, it will be either a single int or a list of ints 
    #check if data is a single int
    if isinstance(data, int):
        #if yes then save the int itself
        f.write(str(data))
    else: 
        #if not int then it will be a list of ints so iterate through list and save to file
        for val in data:
            f.write(str(val) + '\n')
    f.close()
    return




env = gym.make("CustomTetris-v0")


#Q_learning
####Parameters####
STEP_SIZE = 0.01
GAMMA = 0.99
EPSILON = 0.01
number_of_training_episodes = 1000
number_of_pieces_to_drop = 5000
##################

def Q_learning_TD(env, number_of_training_episodes, GAMMA, STEP_SIZE, EPSILON): 

    #data for plotting
    plot_data_lines_cleared = []
    plot_data_row_deletions = []



    #Initialise empty policy dictionary 
        #maps states to actions (this will be grown dynamically as episodes are generated)
            #key is state, value is a dictionary mapping available actions to their respective probabilities
    policy = {}
    

    #Initialise empty Q dictionary 
        #key is state, value is a dictionary mapping actions to respective action-values for the state
    Q = {}
    
   
    episode_number = 0
    #LOOP THROUGH NUMBER OF TRAINING EPISODES
    for episode in range(number_of_training_episodes):
        
        state = env.reset() 
        
        episode_number += 1

        for _ in range(number_of_pieces_to_drop): 
           
            # env.render()  #uncomment this to render the game graphically

            usable_state = convert_state_to_usable_key(state)
            field, tet_piece = usable_state
            #if state-actions don't exist for this state, then add entry to the Q dictionary
            if usable_state not in Q:
                action_values = {}

                #List holds all comninations of rotations to possible columns for this state's tetromino
                list_of_combinations = env.get_valid_actions(tet_piece)

                #initialise each action value
                for a in list_of_combinations:
                    action_values[a] = 0.0

                #assign action values to the state
                Q[usable_state] = action_values
                
            #choose A from S using policy derived from Q (e.g epsilon-greedy)
                #choose max value action
            maximum_action_value = max(Q[usable_state].values())
            relevant_actions = Q[usable_state].items()

            candidate_max_value_actions = []

            for key, value in relevant_actions:
                if value == maximum_action_value:
                    candidate_max_value_actions.append(key)
                    

            #choose action, Exploit
            action = random.choice(candidate_max_value_actions)

            #choose action, Explore
            if random.random() <EPSILON:
                action = random.choice(list(Q[usable_state].keys()))

            #perform action and unpack results
            next_state, reward, terminal = env.step(action)

            usable_next_state = convert_state_to_usable_key(next_state)

            next_field, next_tet_piece = usable_next_state
            
            #if state-actions don't exist for this next_state, then add entry to the Q dictionary
            if usable_next_state not in Q:
                action_values = {}
                
                #List holds all comninations of rotations to possible columns for this state's tetromino
                list_of_combinations = env.get_valid_actions(next_tet_piece)


                #initialise each action value
                for a in list_of_combinations:
                    action_values[a] = 0.0

                #assign action values to the next_state
                Q[usable_next_state] = action_values
                
            
            #perform update
            maximum_action_value = max(Q[usable_next_state].values())

            relevant_actions = Q[usable_next_state].items()

            candidate_max_value_actions = []

            for key, value in relevant_actions:
                if value == maximum_action_value:
                    candidate_max_value_actions.append(key)
            best_next_action = random.choice(candidate_max_value_actions)

            #td_target = reward + GAMMA * Q[usable_next_state][best_next_action] 
            
            #td_delta = td_target - Q[usable_state][action] 
            #Q[usable_state][action] += STEP_SIZE * td_delta 
           
            
            Q[usable_state][action] += STEP_SIZE * ((reward + (GAMMA * Q[usable_next_state][best_next_action])) - Q[usable_state][action])
                        
    
            state = next_state 
        plot_data_lines_cleared.append(env.get_lines_cleared())
        plot_data_row_deletions.append(env.get_number_row_deletions())
        print("Episode %d, Lines Cleared: %d, Rows Deleted: %d" % (episode_number, env.get_lines_cleared(), env.get_number_row_deletions()))

    
    #Save relevant data to files for plotting
    save_data_to_file(plot_data_lines_cleared, "SavedTrainingData/4x6rowQ/4x10rowQLinesCleared%dEpisodes.txt" %(number_of_training_episodes))
    save_data_to_file(plot_data_row_deletions, "SavedTrainingData/4x6rowQ/4x10rowQRowsDeleted%dEpisodes.txt" %(number_of_training_episodes))
    #Plot Relevant Data
    plt.title("4x%d Q-Learning Lines Cleared" % (env.get_number_tetris_columns()))
    plt.legend()
    plt.plot(plot_data_lines_cleared)
    plt.ylabel("Lines Cleared after 5000 Tetrominos")
    plt.xlabel("Episodes")
    plt.savefig("SavedTrainingData/4x6rowQ/lines_cleared_plot_%d_episodes_Epsilon_%g.png" %(number_of_training_episodes, EPSILON))
    plt.show()

    plt.title("4x%d Q-Learning Rows Deleted" % (env.get_number_tetris_columns()))
    plt.legend()
    plt.plot(plot_data_row_deletions)
    plt.ylabel("Rows Deleted after 5000 Tetrominos")
    plt.xlabel("Episodes")
    plt.savefig("SavedTrainingData/4x6rowQ/row_deletions_plot_%d_episodes_Epsilon_%g.png" %(number_of_training_episodes, EPSILON))
    plt.show()
    
    #helper function used during training
def convert_state_to_usable_key(state):
    field, tet_piece = state
    return (','.join(map(str, field)), tet_piece)


#Begin Training
Q_learning_TD(env, number_of_training_episodes, GAMMA, STEP_SIZE, EPSILON)            



