import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt

#This code for random agent ()
env = gym.make("CustomTetris-v0")

terminated = False
current_num = 0

list_of_lines_cleared = []
list_of_row_deletions = []
for episode_number in range(1000):
    state = env.reset()
    for _ in range (5000):
        #env.render() #uncomment this to render the game graphically
        
        #unpack state
        field, tet_piece = state
        
        #get valid actions
        valid_actions = env.get_valid_actions(tet_piece)

        #select valid actions
        action = random.choice(valid_actions)
        
        #perform action in Tetris environment
        next_state, reward, terminal = env.step(action)
        
        state = next_state

    list_of_lines_cleared.append(env.get_lines_cleared())
    list_of_row_deletions.append(env.get_number_row_deletions())
    print("Episode %d, Lines Cleared: %d, Rows Deleted: %d" % (episode_number+1, env.get_lines_cleared(), env.get_number_row_deletions()))

    

#get average lines cleared
average_lines_cleared = sum(list_of_lines_cleared) / len(list_of_lines_cleared)

#get average row deletions
average_row_deletions = sum(list_of_row_deletions) / len(list_of_row_deletions)
print(average_lines_cleared)
print(average_row_deletions)

