
import warnings

from torch._C import dtype

from DQN.DQN import ReplayMemory, DQN, Experience
import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt
import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T  
import time



#function used to save raw lines cleared and rows deleteed data to text file
def save_data_to_file(data, name):
    f = open(name, 'w')

    #based on the data I choose to save, it will be either a single int or a list of ints 
    #check if data is a single int
    if isinstance(data, int):
        #if yes then save the int itself
        f.write(str(data))
    else: 
        #if not int then it will be a list of ints so iterate through list and save to file
        for val in data:
            f.write(str(val) + '\n')
    f.close()
    return




def get_predicted_q_values(state_batch, action_batch, neural_network):

    inp_for_dqn = torch.zeros(len(state_batch), dqn_input_size)

    for i in range(len(state_batch)):
        #capture field and tet_piece
        field, tet_piece = state_batch[i]

        #list for tensor will be of the form [...field elements...,tet_piece, col, rot ]
        list_for_tensor = []

        #add each element of field to list_for_tensor first
        for nested_list in field:
            for element in nested_list:
                list_for_tensor.append(element)
        
        #add tet_piece to list_for_tensor second
        list_for_tensor.append(tet_piece)

        #capture col and rot
        col, rot = action_batch[i]

        #add column to list_for_tensor third
        list_for_tensor.append(col)

        #add rotation to list_for_tensor fourth
        list_for_tensor.append(rot)

        t = torch.tensor(list_for_tensor, dtype = torch.float32)

        inp_for_dqn[i,:] = t

    predicted_q_values = neural_network(inp_for_dqn).flatten()
    
    return predicted_q_values






def get_next_q_values(next_state_batch, target_network, env):

    #for each next_state perform every possible action and only store the highest Q-value (will be stored as a tensor)
    list_of_next_q_values = []

    for n_s_t in next_state_batch:
        field, tet_piece = n_s_t
        
       
        valid_actions = env.get_valid_actions(tet_piece)

        list_of_action_values = []

        inp_for_dqn = torch.zeros(len(valid_actions), dqn_input_size)

        for i in range(len(valid_actions)):
            a = valid_actions[i]
            col, rot = a

            #list for tensor will be of the form [...field elements...,tet_piece, col, rot ]
            list_for_tensor = []

            #add each element of field to list_for_tensor first
            for nested_list in field:
                for element in nested_list:
                    list_for_tensor.append(element)
            
            #add tet_piece to list_for_tensor second
            list_for_tensor.append(tet_piece)

            #add column to list_for_tensor third
            list_for_tensor.append(col)

            #add rotation to list_for_tensor fourth
            list_for_tensor.append(rot)

            t = torch.tensor(list_for_tensor, dtype = torch.float32)

            inp_for_dqn[i,:] = t

        with torch.no_grad():
            list_of_action_values = target_network(inp_for_dqn)                
        max_action_indice = torch.argmax(list_of_action_values)
        highest_value = list_of_action_values[max_action_indice]
        action = valid_actions[max_action_indice]
        list_of_next_q_values.append(highest_value)

    #merge the tensors in list_of_next_q_values_tensors into 1 tensor
    next_q_values = torch.tensor(list_of_next_q_values, dtype = torch.float32)
    return next_q_values
    

def get_target_q_values(next_q_values, reward_batch, gamma):
    return  (next_q_values * gamma) + torch.tensor(reward_batch, dtype = torch.float32)

def select_action_eps_greedy(env, state, neural_network, eps, dqn_input_size):
    #unpack state
    field, tet_piece = state
    #List holds all comninations of rotations to possible columns for this state's tetromino
    valid_actions = env.get_valid_actions(tet_piece)

    #with eps probability, select random action
    if random.random() < eps:
            action = random.choice(valid_actions) 
            return action
    else:
        with torch.no_grad():
            list_of_action_values = []

            inp_for_dqn = torch.zeros(len(valid_actions), dqn_input_size)

            for i in range(len(valid_actions)):
                a = valid_actions[i]
                col, rot = a

                #list for tensor will be of the form [...field elements...,tet_piece, col, rot ]
                list_for_tensor = []

                #add each element of field to list_for_tensor first
                for nested_list in field:
                    for element in nested_list:
                        list_for_tensor.append(element)
                
                #add tet_piece to list_for_tensor second
                list_for_tensor.append(tet_piece)

                #add column to list_for_tensor third
                list_for_tensor.append(col)

                #add rotation to list_for_tensor fourth
                list_for_tensor.append(rot)

                t = torch.tensor(list_for_tensor, dtype = torch.float32)

                inp_for_dqn[i,:] = t


            list_of_action_values = neural_network(inp_for_dqn)
            #get indice of the maximum value returned
            max_action_indice = torch.argmax(list_of_action_values)
            highest_value = list_of_action_values[max_action_indice]
            action = valid_actions[max_action_indice]
            return action




############ TRAINING CODE ####################



env = gym.make("CustomTetris-v0")

####Parameters####
gamma = 0.99
eps = 1
eps_final = 0.001 #epsilon final is the lowest epsilon after decay
eps_decay = 0.0001 #epsilon decay is the number to reduce epsilon by after each timestep
target_network_update = 4 #After every 4 episodoes the target network weights will be updated to equal the neural network's weights
replay_memory_size = 30000 #Capacity of replay memory in terms of number of experiences storable
batch_size = 128 #size of batch of experiences sampled from replay memory
learning_rate = 0.001 #learning rate used during the training of the neural network
number_episodes = 100 #number of episodes to train for
number_of_pieces_to_drop = 5000 #number of tetrominos to drop in each episode
dqn_input_size = 3+(env.get_number_tetris_columns()*4) #number of neurons in input layer (should equal size of state tensor), in this case state-action is [...field elements...,tet_piece, col, rot]
run_on_device = 'cpu' 
#if torch.cuda.is_available():
#    run_on_device = 'cuda'
##################


memory = ReplayMemory(replay_memory_size)



#create 2 instances of the DQN class, one for neural network one for target network
neural_network = DQN(dqn_input_size).to(run_on_device)
neural_network.train()
target_network = DQN(dqn_input_size).to(run_on_device)
target_network.load_state_dict(neural_network.state_dict())
target_network.eval() #sets target net to not be in training mode
optimizer = optim.Adam(params=neural_network.parameters(), lr=learning_rate)

#lists for plotting
plot_data_lines_cleared = []
plot_data_row_deletions = []

#these values are used to track important statistics about the best lines cleared and lowest rows deleted. Lowest_rows_deleted is initialised to a high value due to the way in which it is updated; 
#the algorithm checks whether rows deleted was lower than lowest_row_deletions to update it
highest_lines_cleared = 0
lowest_row_deletions = 200000

#now ready to start training
for episode in range(1, number_episodes+1):  #for each episode
    
    state = env.reset() #reset environment and obtain the starting state

    tet_piece_dropped = 0
    start = time.time()
    for timestep in range(number_of_pieces_to_drop): #for each timestep within each episode
        #env.render()
        tet_piece_dropped +=1

            
        
        action = select_action_eps_greedy(env, state, neural_network, eps, dqn_input_size) #select action based on epsilon greedy policy
       

        next_state, reward, terminal = env.step(action) # capture next_state and reward (terminal not necessary for melax version) observation
        

        memory.push(Experience(state,action,next_state,reward)) #store the observation in the replay memory 

        state = next_state #current state is now the next_state in environment
     
        if memory.can_provide_sample(batch_size): # would like to sample a batch_size number of observations from replay memory in order to train the neural network, so check if enough observations have been gathered.
            
            #sample a number of experiences equal to the the batch-size
            experiences = memory.sample(batch_size) 

            #create ordered lists of states, actions, next_states, rewards
            zipped_experiences = Experience(*zip(*experiences))

            #capture each individual list
            state_batch = zipped_experiences.state
            action_batch = zipped_experiences.action
            next_state_batch = zipped_experiences.next_state
            reward_batch = zipped_experiences.reward

            predicted_q_values = get_predicted_q_values(state_batch, action_batch, neural_network) #obtain predicted q-values
            next_q_values = get_next_q_values(next_state_batch, target_network, env) #obtain q values for the next-state
            target_q_values = get_target_q_values(next_q_values, reward_batch, gamma) #obtain target_q_values

            
       
            optimizer.zero_grad() #sets gradients to zero, according to pytorch.
            loss = F.huber_loss(predicted_q_values, target_q_values) #calculates the loss between predicted_q_values and the target_q_values using huber loss.
            loss.backward() #calculate gradients of the loss with respect to the neural network's weights using backpropagation.
            optimizer.step() #Update the weights of the neural network
            

            if episode % target_network_update == 0: #check whether to update the target network's weights to neural network's weights
                target_network.load_state_dict(neural_network.state_dict())

            
            if timestep%3 == 0 and eps>eps_final: # check whether to update the epsilon value
                eps-=eps_decay
                if eps < eps_final:
                    eps = eps_final
        
    print("total time = {}".format(time.time()-start))
    print("Episode %d, Lines Cleared: %d, Rows Deleted: %d" % (episode, env.get_lines_cleared(), env.get_number_row_deletions()))
    plot_data_lines_cleared.append(env.get_lines_cleared())
    plot_data_row_deletions.append(env.get_number_row_deletions())



#################### This portion is used for Saving relevant results ###########################

#Save relevant data to files for plotting
save_data_to_file(plot_data_lines_cleared, "SavedTrainingData/4x%drowDQN/LinesCleared4rowDQN%dEpisodesTNUC4_EPS001_LR001.txt" %(env.get_number_tetris_columns(), number_episodes))
save_data_to_file(plot_data_row_deletions, "SavedTrainingData/4x%drowDQN/RowDeletions4rowDQN%dEpisodesTNUC4_EPS001_LR001.txt" %(env.get_number_tetris_columns(), number_episodes))


#create and show plots
plt.title("4x%d DQN Tetris Lines Cleared" % (env.get_number_tetris_columns()))
plt.plot(plot_data_lines_cleared)
plt.ylabel("Lines Cleared After 5,000 Tetrominos")
plt.xlabel("Episode Number")
plt.savefig("SavedTrainingData/4x%drowDQN/lines_cleared_plot_%d_episodes_TNUC4_EPS001_LR001.png" %(env.get_number_tetris_columns(), number_episodes))
plt.show()


plt.title("4x%d DQN Tetris Row Deletions" % (env.get_number_tetris_columns()))
plt.plot(plot_data_row_deletions)
plt.ylabel("Rows Deleted After 5,000 Tetrominos")
plt.xlabel("Episode Number")
plt.savefig("SavedTrainingData/4x%drowDQN/row_deletions_plot_%d_episodes_TNUC4_EPS001_LR001.png" %(env.get_number_tetris_columns(), number_episodes))
plt.show()

env.close() #close environment