"""
The code for the namedtuple and ReplayMemory class was borrowed from DeepLizard; https://deeplizard.com/learn/video/PyQNfsGUnQA
"""


import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt
import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
from itertools import count
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T  



class DQN(nn.Module):
    def __init__(self, input_size):
        super(DQN, self).__init__()
        #linear layers are fully connected layers
        self.inp_layer = nn.Sequential(nn.Linear(input_size, input_size), nn.ReLU(inplace=True))
        self.hidden_layer_1 = nn.Sequential(nn.Linear(input_size, input_size), nn.ReLU(inplace=True))
        self.hidden_layer_2 = nn.Sequential(nn.Linear(input_size, input_size), nn.ReLU(inplace=True))
        self.hidden_layer_3 = nn.Sequential(nn.Linear(input_size, input_size), nn.ReLU(inplace=True))
        self.hidden_layer_4 = nn.Sequential(nn.Linear(input_size, input_size), nn.ReLU(inplace=True))

        self.out_layer = nn.Sequential(nn.Linear(input_size, 1))
    
    
    def forward(self, x):
        x = self.inp_layer(x)
        x = self.hidden_layer_1(x)
        x = self.hidden_layer_2(x)
        x = self.hidden_layer_3(x)
        x = self.hidden_layer_4(x)
        x = self.out_layer(x)
        return x



Experience = namedtuple(
    'Experience',
    ('state', 'action', 'next_state', 'reward')
)

class ReplayMemory():
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.push_count = 0

    def push(self, experience):
        if len(self.memory) < self.capacity:
            self.memory.append(experience)
        else:
            self.memory[self.push_count % self.capacity] = experience
        self.push_count += 1

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)
    
    def can_provide_sample(self, batch_size):
        return len(self.memory) >= batch_size

