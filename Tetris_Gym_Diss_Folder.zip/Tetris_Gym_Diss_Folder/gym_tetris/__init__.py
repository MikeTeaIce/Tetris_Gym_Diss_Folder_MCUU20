from gym.envs.registration import register

register(
    id='CustomTetris-v0',
    entry_point='gym_tetris.envs:CustomTetrisEnv',
)


register(
    id='StandardTetris-v0',
    entry_point='gym_tetris.envs:StandardTetrisEnv',

)

