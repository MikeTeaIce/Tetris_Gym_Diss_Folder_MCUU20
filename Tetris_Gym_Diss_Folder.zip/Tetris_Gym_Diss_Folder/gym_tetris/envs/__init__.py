from gym_tetris.envs.custom_tetris_env import *
from gym_tetris.envs.custom_tetris_file import CustomTetris
from gym_tetris.envs.standard_tetris_env import *
from gym_tetris.envs.standard_tetris_file import StandardTetris
