
"""
The code in this file was borrowed from https://levelup.gitconnected.com/writing-tetris-in-python-2a16bddb5318 and heavily adapted and augmented.

These classes were borrowed and heavily adapted:
    class Tetromino (somewhat adapted)
    class CustomTetris (heavily adapted)

These functions were borrowed and some were partially adapted:
    def breaklines(self)
    def go_down(self)
    def freeze(self)
    def new_tetromino(self)
    def draw_board(self):
    def go_side(self)
    def rotate(self)

"""



from numpy import extract, number, tracemalloc_domain
import pygame
import math
import random
import copy
# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
SPACE_GRAY = (52, 61, 82)
GRAY = (128, 128, 128)

size = (400, 500)
screen = pygame.display.set_mode(size)

#Initialise a list of colours for the pieces 


#class for a Tetromino piece
class Tetromino:
    x = 0
    y = 0
    tet_rgb_color = (255, 49, 49)
    
    #list of 7 tetromino pieces, where each tetromino piece is a list of its possible rotations 
    #the first index of a given tetromino rotation list is its default starting position 
    tetrominos = [
        [[1, 5, 9, 13], [4, 5, 6, 7]],
        [[4, 5, 9, 10], [2, 6, 5, 9]],
        [[6, 7, 9, 10], [1, 5, 6, 10]],
        [[1, 2, 5, 9], [0, 4, 5, 6], [1, 5, 9, 8], [4, 5, 6, 10]],
        [[1, 2, 6, 10], [5, 6, 7, 9], [2, 6, 10, 11], [3, 5, 6, 7]],
        [[1, 4, 5, 6], [1, 4, 5, 9], [4, 5, 6, 9], [1, 5, 6, 9]],
        [[1, 2, 5, 6]],
    ]

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.tet_piece = random.randint(0, len(self.tetrominos) - 1)
        self.color = self.tet_rgb_color
        self.rotation = 0

    def image(self):
        return self.tetrominos[self.tet_piece][self.rotation]

    def rotate(self):
        self.rotation = (self.rotation + 1) % len(self.tetrominos[self.tet_piece])



class StandardTetris:
    level = 2
    x = 100
    y = 60
    zoom = 20
    fps = 45
    screen_dimensions = (400, 500)
    rendering = False
    def __init__(self, height, width):
        pygame.init()
        self.screen = pygame.display.set_mode(self.screen_dimensions)
        self.height = height
        self.width = width
        self.tetromino = Tetromino((width-4)//2,0)
        self.field = []
        self.score = 0
        self.linesCleared = 0
        self.row_deletions = 0
        self.reward = 0
        self.gameLost = False
        for i in range(height):
            new_line = []
            for j in range(width):
                new_line.append(0)
            self.field.append(new_line)

    def new_tetromino(self):
        self.tetromino = Tetromino((self.width-4)//2,0)
        
    def intersects(self):
        intersection = False
        for i in range(4):
            for j in range(4):
                if i * 4 + j in self.tetromino.image():
                    if i + self.tetromino.y > self.height - 1 or \
                            j + self.tetromino.x > self.width - 1 or \
                            j + self.tetromino.x < 0 or \
                            self.field[i + self.tetromino.y][j + self.tetromino.x] > 0:
                        intersection = True
        return intersection

    def break_lines(self):
        lines = 0
        for i in range(1, self.height):
            zeros = 0
            for j in range(self.width):
                if self.field[i][j] == 0:
                    zeros += 1
            if zeros == 0:
                lines += 1
                for i1 in range(i, 1, -1):
                    for j in range(self.width):
                        self.field[i1][j] = self.field[i1 - 1][j]
        self.reward += (lines**2)*10
        self.score += lines ** 2
        self.linesCleared += lines


    def hard_drop(self):
        while not self.intersects():
            self.tetromino.y += 1
        self.tetromino.y -= 1
        self.freeze()
        return True

    def go_down(self):
        self.tetromino.y += 1
        if self.intersects():
            self.tetromino.y -= 1
            self.freeze()
            return True
        return False

    def freeze(self):
        for i in range(4):
            for j in range(4):
                if i * 4 + j in self.tetromino.image():
                    self.field[i + self.tetromino.y][j + self.tetromino.x] = 1
        self.break_lines()
        self.new_tetromino()
        if self.intersects():
            self.gameLost = True
            self.reward-=200
    
    
    def go_side(self, dx):
        old_x = self.tetromino.x
        self.tetromino.x += dx
        if self.intersects():
            self.tetromino.x = old_x

    def rotate(self):
        old_rotation = self.tetromino.rotation
        self.tetromino.rotate()
        if self.intersects():                                                            
            self.tetromino.rotation = old_rotation

    
    def draw_board(self):
        #draw the field squares
        for i in range(self.height):
            for j in range(self.width):
                pygame.draw.rect(self.screen, GRAY, [self.x + self.zoom * j, self.y + self.zoom * i, self.zoom, self.zoom], 1)
                if self.field[i][j] > 0:
                    pygame.draw.rect(self.screen, self.tetromino.color,
                                    [self.x + self.zoom * j + 1, self.y + self.zoom * i + 1, self.zoom - 2, self.zoom - 1])
        #draw the tetromino image
        if self.tetromino is not None:
            for i in range(4):
                for j in range(4):
                    p = i * 4 + j
                    if p in self.tetromino.image():
                        pygame.draw.rect(self.screen, self.tetromino.color,
                                        [self.x + self.zoom * (j + self.tetromino.x) + 1,
                                        self.y + self.zoom * (i + self.tetromino.y) + 1,
                                        self.zoom - 2, self.zoom - 2])


    def get_valid_rotations(self, tet_piece):
        tetrominos = [
        [[1, 5, 9, 13], [4, 5, 6, 7]],
        [[4, 5, 9, 10], [2, 6, 5, 9]],
        [[6, 7, 9, 10], [1, 5, 6, 10]],
        [[1, 2, 5, 9], [0, 4, 5, 6], [1, 5, 9, 8], [4, 5, 6, 10]],
        [[1, 2, 6, 10], [5, 6, 7, 9], [2, 6, 10, 11], [3, 5, 6, 7]],
        [[1, 4, 5, 6], [1, 4, 5, 9], [4, 5, 6, 9], [1, 5, 6, 9]],
        [[1, 2, 5, 6]],
        ]
        possible_rotations = tetrominos[tet_piece]
        return list(range(0,len(possible_rotations)))
    
    

    def close(self):
        pygame.quit

    def get_valid_columns(self, tet_piece, rotation):
        """
        validColumnsForTetAndRot = [
        
        [(-1,0,1,2,3,4,5,6,7,8),(0,1,2,3,4,5,6)],
        [(0,1,2,3,4,5,6,7),(-1,0,1,2,3,4,5,6,7)],
        [(-1,0,1,2,3,4,5,6),(-1,0,1,2,3,4,5,6,7)],
        [(-1,0,1,2,3,4,5,6,7),(0,1,2,3,4,5,6,7),(0,1,2,3,4,5,6,7,8),(0,1,2,3,4,5,6,7)],
        [(-1,0,1,2,3,4,5,6,7),(-1,0,1,2,3,4,5,6),(-2,0,1,2,3,4,5,6),(-1,0,1,2,3,4,5,6)],
        [(0,1,2,3,4,5,6,7),(0,1,2,3,4,5,6,7,8),(0,1,2,3,4,5,6,7),(-1,0,1,2,3,4,5,6,7)],
        [(-1,0,1,2,3,4,5,6,7)]
        ]
        """
        """
        validColumnsForTetAndRot = [
        [list(range(-1,9)),list(range(0,7))],
        [list(range(0,8)),list(range(-1,8))],
        [list(range(-1,7)),list(range(-1,8)],
        [list(range(-1,8)),list(range(0,8)),list(range(0,9)),list(range(0,8))],
        [list(range(-1,8)),list(range(-1,7)),list(range(-2,7)),list(range(-1,7))],
        [list(range(0,8)),list(range(0,9)),list(range(0,8)),list(range(-1,8))],
        [list(range(-1,8))]
        ]
        """
        validColumnsForTetAndRot = [
        [list(range(-1,self.width-1)),list(range(0,self.width-3))],
        [list(range(0,self.width-2)),list(range(-1,self.width-2))],
        [list(range(-1,self.width-3)),list(range(-1,self.width-2))],
        [list(range(-1,self.width-2)),list(range(0,self.width-2)),list(range(0,self.width-1)),list(range(0,self.width-2))],
        [list(range(-1,self.width-2)),list(range(-1,self.width-3)),list(range(-2,self.width-3)),list(range(-1,self.width-3))],
        [list(range(0,self.width-2)),list(range(0,self.width-1)),list(range(0,self.width-2)),list(range(-1,self.width-2))],
        [list(range(-1,self.width-2))]
        ]
        return validColumnsForTetAndRot[tet_piece][rotation]
    
    
    #performs action in the Tetris game
    def step(self, action):
        #action is a tuple of (column, rotation)            
        action_col, action_rot = action

        current_rotation = 0
        if self.rendering == False:

            #Handle rotation
            while current_rotation < action_rot:
                self.tetromino.rotate()
                current_rotation += 1
            
            #Handle column
            #go_side takes dx (change in x) as argument, hence col-currCol gives required dx to move tet to col
            currCol = self.tetromino.x
            self.go_side(action_col-currCol)
            
            #Handle piece drop
            self.hard_drop()
            
        else:
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
            


            #Handle rotation
            while current_rotation < action_rot:
                self.tetromino.rotate()
                current_rotation += 1
            
            #Handle column
            #go_side takes dx (change in x) as argument, hence col-currCol gives required dx to move tet to col
            currCol = self.tetromino.x
            self.go_side(action_col-currCol)

            
            #Handle rendering piece drop
            piece_frozen = False
            while piece_frozen == False:
                if self.gameLost == False:
                    
                    #piece_frozen = self.hard_drop()
                    piece_frozen = self.go_down()
                  
                #fills game screen with colour, for rgb do fill((..., ..., ...))
                screen.fill(SPACE_GRAY)
                self.draw_board()
                
                font1 = pygame.font.SysFont('Arial', 25, True, False)
                font2 = pygame.font.SysFont('Arial', 65, True, False)
                text = font1.render("Score: " + str(self.score), True, self.tetromino.color)
                text1 = font1.render("Lines Cleared: " + str(self.linesCleared), True, self.tetromino.color)
                text_game_over = font2.render("Game Over", True, WHITE)
                text_game_over1 = font2.render("Press ESC", True, WHITE)

                screen.blit(text, [0, 0])
                screen.blit(text1, [0, 30])
                if self.gameLost == True:
                    screen.blit(text_game_over, [20, 200])
                    screen.blit(text_game_over1, [25, 265])
                    

                pygame.display.flip()
                pygame.time.Clock().tick(self.fps)

        
        
        next_state, _ = self.extract_state_from_field()
        next_state = (next_state, self.tetromino.tet_piece)
        
        """
        print("next state")
        for lst in next_state:
            print(lst)
        print(self.convert_state_to_heuristics(next_state))
        [print('\n')]
        """
        current_reward = self.reward
        terminated_status = self.gameLost
        observation = (next_state, current_reward, terminated_status)
        self.reward = 0
        self.rendering = False
        return observation
  

    def render(self):
        self.rendering = True



    def get_valid_actions(self, tet_piece):
        #List to hold all comninations of rotations to possible columns for this state's tetromino
        list_of_combinations = []

        #obtain combinations
        for rot in self.get_valid_rotations(tet_piece):
            for col in self.get_valid_columns(tet_piece, rot):
                list_of_combinations.append((col,rot))
        return list_of_combinations

    ####>>>>> FUNCTIONS REQUIRED F0R 4-ROW TETRIS <<<<####
    def get_height_of_tallest_column(self):
        #get height of piece configuration
        height_of_tallest_column = 0
        for i in reversed(range(self.height)):
            for j in range(self.width):
                if self.field[i][j] != 0:
                    height_of_tallest_column = self.height-i
                    break
        
        return height_of_tallest_column

    #####################################################



    ##############<<<<<< REQUIRED FOR HEURISTICS >>>>>#################
    def extract_state_from_field(self):
        extracted_state = self.field[len(self.field)-4:(len(self.field))]
       
        bottom_row_of_state_height_from_bottom = 0
        #take only top 4 rows as extracted_state
        for row in range(len(self.field)):
            for col in range(len(self.field[row])):
                if self.field[row][col] != 0:
                    #if row is higher than 4 rows from bottom, then state representation of 4 rows will start at the current row and include 3 more rows down
                        #otherwise just take bottom 4 rows which is what extracted_state is set to by default so do nothing in that case
                    if row < len(self.field)-4:
                        bottom_row_of_state_height_from_bottom = self.height - (row+4)
                        return self.field[row:row+4], bottom_row_of_state_height_from_bottom 

        return extracted_state, bottom_row_of_state_height_from_bottom

    def retrieve_poss_next_states_heuristics(self):
      
        #get current important values (WILL NEED TO RESET THE TETROMINO AND FIELD AFTER EACH ACTION SIMULATED)
        curr_x = copy.copy(self.tetromino.x)
        curr_y = copy.copy(self.tetromino.y)
        curr_rot = copy.copy(self.tetromino.rotation)
        curr_field = [x[:] for x in self.field]
 
        #Dictionary to hold the next_states after simulating each action 
        poss_next_state_heuristics = {}

        
        valid_actions = self.get_valid_actions(self.tetromino.tet_piece)

        for a in valid_actions:
            #bottom row of state is needed because highest column will be calculated in relation to this row so that it is consistent with the states used to train the neural net
            _, bottom_row_of_state_height_from_bottom = self.extract_state_from_field()
            
            action_col, action_rot = a

            current_rotation = 0
            #handle rotation
            while current_rotation < action_rot:
                self.tetromino.rotate()
                current_rotation += 1
            
            #Handle column
            #go_side takes dx (change in x) as argument, hence col-currCol gives required dx to move tet to col
            currCol = self.tetromino.x
            self.go_side(action_col-currCol)
            
            #Handle piece drop
                #get relevant code from self.hard_drop() and freeze() excluding the break_lines()

           
            while not self.intersects():
                self.tetromino.y += 1
            self.tetromino.y -= 1
            for i in range(4):
                for j in range(4):
                    if i * 4 + j in self.tetromino.image():
                        self.field[i + self.tetromino.y][j + self.tetromino.x] = 1 
 
      
            #get useful heuristics from this state, of the form [lines cleared, aggregate height, number of holes, bumpiness, height of tallest column]
                
                #break and track completed lines
            lines = 0
            for i in range(1, self.height):
                zeros = 0
                for j in range(self.width):
                    if self.field[i][j] == 0:
                        zeros += 1
                if zeros == 0:
                    lines += 1
                    for i1 in range(i, 1, -1):
                        for j in range(self.width):
                            self.field[i1][j] = self.field[i1 - 1][j]
            

            
                #height of tallest column (for consistency with the custom 4-row tetris game which was used to train the neural network, this height of tallest column is the height when starting from the bottom row of the 4-row current state)
            height_of_tallest_column = self.get_height_of_tallest_column() - bottom_row_of_state_height_from_bottom
            #print(height_of_tallest_column)

            #doing this has same effect of reducing height to 4 from the custom environment since it now gets the top 4 rows at the state, and then the remaining heuristics are derived from this
            f_d,_ = self.extract_state_from_field()
                #number of holes
            number_of_holes = 0
            for row in range(1, len(f_d)):
                for col in range(self.width):
                    curr_square = f_d[row][col]
                    if curr_square == 0:
                        if f_d[row-1][col] != 0:
                            number_of_holes += 1
            
                #bumpiness
            list_of_column_heights = [0]*self.width
            for col in range(self.width):
                for row in range(len(f_d)):
                    if f_d[row][col] != 0:
                        list_of_column_heights[col] = (4-row)
                        break
            bumpiness = 0
            for i in range(len(list_of_column_heights)-1):
                bumpiness += abs(list_of_column_heights[i] - list_of_column_heights[i+1])

                #aggregate height
            aggregate_height = 0
            for i in range(len(list_of_column_heights)):
                aggregate_height+=list_of_column_heights[i]

                  
            poss_next_state_heuristics[a] = [lines, aggregate_height, number_of_holes, bumpiness, height_of_tallest_column]
            #reset changes
            self.tetromino.x = curr_x
            self.tetromino.y = curr_y
            self.tetromino.rotation = curr_rot

            self.field = [x[:] for x in curr_field]

        return poss_next_state_heuristics

        
    
    def convert_state_to_heuristics(self, s_t):
    
        f_d, _ = s_t
        #get useful heuristics from this state, of the form [lines, aggregate_height, number_of_holes, bumpiness, height_of_tallest_column]
            #number of holes
        number_of_holes = 0
        for row in range(1, len(f_d)):
            for col in range(self.width):
                curr_square = f_d[row][col]
                if curr_square == 0:
                    if f_d[row-1][col] != 0:
                        number_of_holes += 1
            


            #bumpiness
        #create list of 0s equal to width
        list_of_column_heights = [0]*self.width
        #get height of each column
        for col in range(self.width):
            for row in range(len(f_d)):
                if f_d[row][col] != 0:
                    list_of_column_heights[col] = (4-row)
                    break
        bumpiness = 0
        #calc bumpiness based on column heights
        for i in range(len(list_of_column_heights)-1):
            bumpiness += abs(list_of_column_heights[i] - list_of_column_heights[i+1])

            #aggregate hight
        aggregate_height = 0
        for i in range(len(list_of_column_heights)):
            aggregate_height+=list_of_column_heights[i]

        #height of tallest column
      
        extracted_state, bottom_row_of_state_height_from_bottom = self.extract_state_from_field()
        height_of_tallest_column = self.get_height_of_tallest_column() - bottom_row_of_state_height_from_bottom
        
        #note that lines will be 0 because the state passed to this function will have had lines removed
        return [0, aggregate_height, number_of_holes, bumpiness, height_of_tallest_column]
    
