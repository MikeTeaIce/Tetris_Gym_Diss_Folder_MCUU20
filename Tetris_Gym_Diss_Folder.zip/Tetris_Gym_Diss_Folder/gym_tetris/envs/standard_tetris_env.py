import gym
from gym import spaces
import numpy as np
from gym_tetris.envs.standard_tetris_file import StandardTetris

class StandardTetrisEnv(gym.Env):
    def __init__(self):
        self.pygame = StandardTetris(20,10)
        self.currentTetromino = self.pygame.tetromino

    def reset(self):
        #reset resets the Tetris state; returns an empty Tetris board with the first tetromino 
        del self.pygame
        self.pygame = StandardTetris(20, 10)
        return (self.pygame.field[len(self.pygame.field)-4: len(self.pygame.field)], self.pygame.tetromino.tet_piece)

    def step(self, action):
        #step performs action on current state
        next_state, reward, done = self.pygame.step(action)
        return (next_state, reward, done)

    def render(self, mode="human", close=False):
        #renders the actual game screen
        self.pygame.render()

    def close(self):
        self.pygame.close()

    def get_valid_actions(self, tet_piece):
        #returns valid actions (tuples of column and rotation) for a given tetromino
        return self.pygame.get_valid_actions(tet_piece)

    def retrieve_poss_next_states_heuristics(self):
        #returns a dictionary of possible actions to next states heuristics
        return self.pygame.retrieve_poss_next_states_heuristics()

    def get_lines_cleared(self):
        #returns number of lines cleared during episode
        return self.pygame.linesCleared
    
    def get_number_row_deletions(self):
        #returnes number of row deletions during episode
        return self.pygame.row_deletions
        
    def convert_state_to_heuristics(self, s_t):
        #converts a state to heuristics representation
        return self.pygame.convert_state_to_heuristics(s_t)
    
    def get_number_tetris_columns(self):
        #gets number of columns in tetris board
        return self.pygame.width

    def get_score(self):
        #returns game score
        return self.pygame.score