from os import linesep

import warnings

from torch._C import dtype

from DQN.DQN import DQN
import sys
import gym
import gym_tetris
import random
import itertools
import matplotlib.pyplot as plt
import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T  
import time
import os


def save_data_to_file(data, name):
    f = open(name, 'w')

    #based on the data I choose to save, it will be either a single int or a list of ints 
    #check if data is a single int
    if isinstance(data, int):
        #if yes then save the int itself
        f.write(str(data))
    else: 
        #if not int then it will be a list of ints so iterate through list and save to file
        for val in data:
            f.write(str(val) + '\n')
    f.close()
    return


Experience = namedtuple(
    'Experience',
    ('state_heuristics', 'next_state_heuristics', 'reward')
    
)


"""
The code for the ReplayMemory class was borrowed from DeepLizard; https://deeplizard.com/learn/video/PyQNfsGUnQA
"""
class ReplayMemory():
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.push_count = 0

    def push(self, experience):
        if len(self.memory) < self.capacity:
            self.memory.append(experience)
        else:
            self.memory[self.push_count % self.capacity] = experience
        self.push_count += 1

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)
    
    def can_provide_sample(self, batch_size):
        return len(self.memory) >= batch_size



def get_target_q_values(next_q_values, reward_batch, gamma):
  
    target_q_values = []
    #for each value in next_q values calculate target using the corresponding reward and gamma
    curr_index = 0
    while curr_index<len(reward_batch):
        target_q_values.append(list((next_q_values[curr_index]*gamma)+reward_batch[curr_index]))
        curr_index+=1

    return torch.tensor(target_q_values, dtype = torch.float32,requires_grad=True)

    

def select_action_eps_greedy(env, state, neural_network, eps):
    #unpack state
    field, tet_piece = state
    #List holds all comninations of rotations to possible columns for this state's tetromino
    valid_actions = env.get_valid_actions(tet_piece)
    #with eps probability, select random action
    if random.random() < eps:
        #get possible next states, will be given as dictionary {action: state, action2, state2, ...}
        possible_next_states = env.retrieve_poss_next_states_heuristics()
        #choose random dictionary entry
        get_rand_next_state_and_corresponding_action = random.choice(list(possible_next_states.items()))
        
        action = get_rand_next_state_and_corresponding_action[0]
        next_state_heuristics = get_rand_next_state_and_corresponding_action[1]
        return action, next_state_heuristics
    else:
        with torch.no_grad():
            #this will capture all possible next state heuristics after taking each possible action
            
            
          

            #get possible next states, will be given as dictionary {action: state, action2, state2, ...}
            possible_next_states = env.retrieve_poss_next_states_heuristics()
            #print(list(possible_next_states.values()))
            inp_for_neural_network = torch.tensor(list(possible_next_states.values()), dtype=torch.float32)
            taken_actions = list(possible_next_states.keys())
            
            max_state_heuristic_value_indice =  torch.argmax(neural_network(inp_for_neural_network))
            
            best_action = taken_actions[max_state_heuristic_value_indice]

            best_next_state = list(possible_next_states.values())[max_state_heuristic_value_indice]
            
            
            return best_action,  best_next_state




env = gym.make("StandardTetris-v0")
####Parameters####
gamma = 0.99
eps = 1
eps_final = 0.001 #epsilon final is the lowest epsilon after decay
eps_decay = 0.001 #epsilon decay is the number to reduce epsilon by after each timestep
target_update = 15 #number of episodes between each time the target network's weights are updated to neural network's weights
replay_memory_size = 30000 #Capacity of replay memory in terms of number of experiences storable 
batch_size = 128 #size of batch of experiences sampled from replay memory
learning_rate = 0.001 #learning rate for the optimiser
number_episodes = 1000 #number of episodes to train for
dqn_input_size = 5 #number of neurons in input layer (should equal size of state tensor) In this case state consists of 5 heuristics -> [lines, aggregate_height, number_of_holes, bumpiness, height_difference]
run_on_device = 'cpu' #Device to run the neural network and tensors on. 'cpu' is CPU, 'cuda' is GPU
#if torch.cuda.is_available():
#    run_on_device = 'cuda'
###################






memory = ReplayMemory(replay_memory_size)



#create 2 instances of the DQN class, one for neural network one for target network
neural_network = DQN(dqn_input_size).to(run_on_device)
neural_network.load_state_dict(torch.load("SavedTrainingData/4x10rowHeuristics/saved_neural_network_state_dict.pth")) #initialise policy_net to the model
neural_network.train()
target_network = DQN(dqn_input_size).to(run_on_device)
target_network.load_state_dict(neural_network.state_dict())
target_network.eval() #sets target net to not be in training mode

optimizer = optim.Adam(params=neural_network.parameters(), lr=learning_rate) #accepts the neaural_network parameters as those we will be optimising

#lists for plotting
plot_data_lines_cleared = []


#Previously highest lines cleared -  This will be used to check if lines-cleared after an episode is higher than a previous lines cleared, if so then save the network weights so that the best performing network weights are retained at the end of the training
previously_highest_lines_cleared = 0


# Training Algorithm
for episode in range(1, number_episodes+1):  #for each episode
    state = env.reset() #reset environment and obtain the starting state
    start = time.time() #track time of episode
    terminated = False
    while terminated == False:
       
        #env.render() #choose whether to render environment timesteps
        state_heuristics = env.convert_state_to_heuristics(state) #convert the state to the 5 heuristics (the heuristic state representation is used for training)

        best_action, next_state_heuristics = select_action_eps_greedy(env, state, neural_network, eps)
        next_state, reward, terminal = env.step(best_action) # observe the next_state, reward, and terminal (terminal not necessary for melax-inspired version)
        terminated = terminal
        memory.push(Experience(state_heuristics,next_state_heuristics,reward)) #store the heuristic from the current state, the next state heuristics (not the observed next_state) and the observed reward in the replay buffer
            #The reason for storing next_state_heuristics instead of converting next_state to heuristics is because next_state_heuristics includes a heuristic (height_of_tallest_column) which is calculated before the height of the next state is reduced to 4 if more than 4.
            #Since height of tallest column is important as it leads to negative reward if > 4, when considering the possible next states derivable from each action in a given state, the possible next states heuristics must include this height of tallest column heuristic 
            #before the column heights are reduced to 4 otherwise it would be pointless to consider it.

        if terminal == True:
            
            #game ended so need to reset environment
            state = env.reset
            plot_data_lines_cleared.append(env.get_lines_cleared())

            print("total time = {}".format(time.time()-start)) #print time of episode
            print("Episode %d, Lines Cleared: %d"% (episode, env.get_lines_cleared())) #print results from episode

            #if the neural net's weights lead to higher lines cleared and also lower row deletions than the previous weights, delete old save and resave the network's weights
            if (env.get_lines_cleared() > previously_highest_lines_cleared):
                previously_highest_lines_cleared = env.get_lines_cleared()
            
                #remove saved weights file if exists, then save new weights file
                if os.path.exists("SavedTrainingData/Reg_Tetris_Heuristics_Learn_From_Scratch/saved_learn_from_scratch_neural_network_state_dict.pth"):
                    os.remove("SavedTrainingData/Reg_Tetris_Heuristics_Learn_From_Scratch/saved_learn_from_scratch_neural_network_state_dict.pth")
                    torch.save(neural_network.state_dict(), "SavedTrainingData/Reg_Tetris_Heuristics_Learn_From_Scratch/saved_learn_from_scratch_neural_network_state_dict.pth")
                else:
                    torch.save(neural_network.state_dict(), "SavedTrainingData/Reg_Tetris_Heuristics_Learn_From_Scratch/saved_learn_from_scratch_neural_network_state_dict.pth")
        else:
            state = next_state #set current state to the observed next_state
            
        if memory.can_provide_sample(batch_size): #would like to sample a batch_size number of observations from replay buffer in order to train the neural_network, but first need to check if enough experiences have been gathered
            experiences = memory.sample(batch_size) #sample a number of experiences equal to the the batch-size
            zipped_experiences = Experience(*zip(*experiences)) #create ordered lists of states, actions, next_states, rewards

            #capture each individual list
            state_heuristics_batch = zipped_experiences.state_heuristics
            next_state_heuristics_batch = zipped_experiences.next_state_heuristics
            reward_batch = zipped_experiences.reward
            #print("reward_batch")
            #print(len(reward_batch))
            #print(reward_batch)

            
            predicted_q_values = neural_network(torch.tensor(state_heuristics_batch, dtype = torch.float32)) #obtain predicted q-values
   

           
            next_q_values = target_network(torch.tensor(next_state_heuristics_batch, dtype= torch.float32)) #obtain next_q_values

            
            target_q_values = get_target_q_values(next_q_values, torch.tensor(reward_batch,dtype=torch.float32), gamma) #obtain target_q_values

            

            optimizer.zero_grad()  #sets gradients to zero, according to pytorch.
            loss = F.huber_loss(predicted_q_values, target_q_values) #calculates the loss between predicted_q_values and the target_q_values using huber loss.
            loss.backward() #calculate gradients of the loss with respect to the neural network's weights using backpropagation.
            optimizer.step() #Update the weights of the neural network

    
            if episode % target_update == 0: #check whether to update the target network's weights to neural_network's weights
                target_network.load_state_dict(neural_network.state_dict())

            
            if  eps>eps_final:
                eps-=eps_decay
                if eps < eps_final:
                    eps = eps_final
                
  




#Save relevant data to files for plotting
save_data_to_file(plot_data_lines_cleared, "SavedTrainingData/Reg_Tetris_Transfer_Learning_Heuristics/LinesClearedTransferLearning%dEpisodes.txt" %(number_episodes))

save_data_to_file(previously_highest_lines_cleared, "SavedTrainingData/Reg_Tetris_Transfer_Learning_Heuristics/Transfer_Learning_saved_model_best_lines_cleared.txt")

#create and show plots
plt.title("Transfer Learning Tetris Heuristics Lines Cleared")
plt.plot(plot_data_lines_cleared)
plt.ylabel("Lines Cleared During Each Episode")
plt.xlabel("Episode Number")
plt.savefig("SavedTrainingData/Reg_Tetris_Transfer_Learning_Heuristics/lines_cleared_plot_%d_episodes.png" %(number_episodes))
plt.show()


#close environment
env.close()





